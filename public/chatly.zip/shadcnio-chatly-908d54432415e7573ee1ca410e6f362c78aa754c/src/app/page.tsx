import Cta from "@/sections/cta";
import Faqs from "@/sections/faqs";
import Features from "@/sections/features";
import Hero from "@/sections/hero";
import Testimonials from "@/sections/testimonials";

const HomePage = () => {
  return (
    <div>
      <Hero />
      <Features />
      <Testimonials />
      <Faqs />
      <Cta />
    </div>
  );
}

export default HomePage;