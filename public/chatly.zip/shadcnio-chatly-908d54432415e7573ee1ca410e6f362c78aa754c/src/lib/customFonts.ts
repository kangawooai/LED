import localFont from "next/font/local";

const gtWalsheim = localFont({
  src: [{ path: "../../font/gt-walsheim.otf" }],
  variable: "--font-gt-walsheim",
});

export { gtWalsheim };

