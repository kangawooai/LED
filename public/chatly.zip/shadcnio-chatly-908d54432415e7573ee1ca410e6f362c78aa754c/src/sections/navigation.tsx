"use client"

import { SlideTabs } from "@/components/common/nav-tabs";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";


const Navigation = () => {
    const [open, setOpen] = useState(false);

    const toggleMenu = () => {
        setOpen((prevOpen) => !prevOpen);
    };

    return (
        <motion.header
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className=" fixed top-6 z-[100] w-full px-4 md:px-0"
        >
            <nav className=" w-full lg:w-fit mx-auto">
                <div className={`bg-background/60 backdrop-blur-md transition-all duration-300 border border-white/10 md:border-none ${open ? 'rounded-3xl' : ' rounded-[2rem] md:rounded-full'}`}>
                    <div className=" w-full py-2.5 pl-6 pr-6 md:py-2 md:pl-4 md:pr-2 flex items-center justify-between md:justify-baseline gap-6">
                        <Link href="/">
                            <div className=" relative h-9 w-[92px]">
                                <Image fill src="/assets/logo.png" quality={100} className=" object-contain" alt="Chatly Logo" />
                            </div>
                        </Link>

                        <SlideTabs />

                        <aside className=" md:hidden">
                            <motion.button
                                initial="hide"
                                animate={open ? "show" : "hide"}
                                onClick={toggleMenu}
                                className="flex flex-col space-y-1.5 h-8 w-12 items-center justify-center relative z-[2147483006]"
                                aria-label={open ? "Close menu" : "Open menu"}
                            >
                                <motion.span
                                    variants={{
                                        hide: {
                                            rotate: 0,
                                        },
                                        show: {
                                            rotate: 45,
                                            y: 4,
                                        },
                                    }}
                                    className="w-[28px] bg-primary rounded-full h-[2.4px] block"
                                ></motion.span>
                                <motion.span
                                    variants={{
                                        hide: {
                                            rotate: 0,
                                        },
                                        show: {
                                            rotate: -45,
                                            y: -4,
                                        },
                                    }}
                                    className="w-[28px] bg-primary rounded-full h-[2.4px] block"
                                ></motion.span>
                            </motion.button>
                        </aside>
                    </div>

                    <AnimatePresence>
                        {open && (
                            <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.3, ease: "easeInOut" }}
                                className="overflow-hidden md:hidden"
                            >
                                <motion.div
                                    initial="hidden"
                                    animate="visible"
                                    exit="hidden"
                                    variants={{
                                        hidden: { opacity: 0 },
                                        visible: {
                                            opacity: 1,
                                            transition: {
                                                staggerChildren: 0.1,
                                                delayChildren: 0.1,
                                            },
                                        },
                                    }}
                                    className="px-6 pb-4 pt-6 space-y-3"
                                >
                                    {["Home", "Features", "Testimonials", "FAQ"].map((item) => (
                                        <motion.div
                                            key={item}
                                            variants={{
                                                hidden: { opacity: 0, y: 20 },
                                                visible: { opacity: 1, y: 0 },
                                            }}
                                            transition={{ duration: 0.3, ease: "easeOut" }}
                                        >
                                            <Link
                                                href={`#${item.toLowerCase()}`}
                                                className="block py-1 text-white/80 hover:text-white transition-colors duration-200"
                                                onClick={() => setOpen(false)}
                                            >
                                                {item}
                                            </Link>
                                        </motion.div>
                                    ))}
                                    <motion.div
                                        variants={{
                                            hidden: { opacity: 0, y: 20 },
                                            visible: { opacity: 1, y: 0 },
                                        }}
                                        transition={{ duration: 0.3, ease: "easeOut" }}
                                        className="pt-2 pb-4"
                                    >
                                        <Link
                                            href="#download"
                                            className="block w-full py-2 px-4 bg-primary text-white font-medium rounded-full text-center transition-transform duration-200 hover:scale-105"
                                            onClick={() => setOpen(false)}
                                        >
                                            Download App
                                        </Link>
                                    </motion.div>
                                </motion.div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </nav>
        </motion.header>
    );
}

export default Navigation;