import { Button } from "@/components/ui/button";
import Image from "next/image";

const Cta = () => {
    return (
        <section id="download" className=" w-full my-28 px-4 md:px-0 lg:px-20 2xl:px-0">
            <div className=" max-w-7xl mx-auto flex flex-col-reverse md:flex-row items-center pt-12 pb-4 md:pt-12 md:pb-12 md:px-12 2xl:px-28 justify-between bg-muted rounded-[2rem] border border-white/20 z-50">

                <div className="flex flex-col items-start h-full p-4 md:p-4 w-full">
                    <p className="text-center mt-2 text-white text-sm md:text-[15px] uppercase">Download the app</p>

                    <h3 className="font-gt-walsheim font-medium text-3xl text-balance md:text-5xl tracking-tight bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent w-full text-start ">
                        Experience the future of <br className=" hidden md:block" /> conversations with Chatly.
                    </h3>

                    <div className=" flex flex-col md:flex-row w-full items-center gap-4 mt-6">
                        <Button size="store" className=" w-full md:w-fit">
                            <div className=" h-12 relative w-[132px] ">
                                <Image fill src="/assets/app-store.png" alt="App Store" quality={100} className=" object-contain" />
                            </div>
                        </Button>
                        <Button size="store" className=" w-full md:w-fit">
                            <div className=" h-12 relative w-[132px] ">
                                <Image fill src="/assets/play-store.png" alt="Play Store" quality={100} className=" object-contain" />
                            </div>
                        </Button>
                    </div>
                </div>

                <div className=" w-full md:w-[320px] h-[24rem] overflow-clip md:h-[600px] relative">
                    <div className=" absolute z-20 inset-0 bg-gradient-to-b from-transparent to-muted md:hidden" />
                    <div className=" w-full md:w-[320px] h-[600px] relative lg:mr-12">
                        <Image fill src={`/assets/screen1.png`} alt={`Get started with Chatly`} quality={40} className=" object-contain " />
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Cta;