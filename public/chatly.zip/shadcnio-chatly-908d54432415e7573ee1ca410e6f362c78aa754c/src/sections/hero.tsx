"use client"

import { Button } from "@/components/ui/button";
import { Marquee } from "@/components/ui/marquee";
import { appScreensColumn1, appScreensColumn2, appScreensColumn3 } from "@/constants";
import { motion } from "framer-motion";
import Image from "next/image";

const Hero = () => {
    return (
        <section className=" mt-12 py-20 w-full min-h-screen">
            <motion.div
                initial="hidden"
                animate="visible"
                variants={{
                    hidden: { opacity: 0 },
                    visible: {
                        opacity: 1,
                        transition: {
                            staggerChildren: 0.2,
                            delayChildren: 0.5,
                        },
                    },
                }}
                className=" container mx-auto px-4 md:px-0 flex flex-col items-center z-50 relative"
            >
                <motion.div
                    variants={{
                        hidden: { opacity: 0, scale: 0.8 },
                        visible: { opacity: 1, scale: 1 },
                    }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className=" size-40 relative"
                >
                    <Image fill src="/assets/logo-icon.png" alt="Chatly Icon" className=" object-contain" />
                </motion.div>
                <motion.h1
                    variants={{
                        hidden: { opacity: 0, y: 30 },
                        visible: { opacity: 1, y: 0 },
                    }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className=" font-gt-walsheim font-medium text-4xl md:text-5xl tracking-tight bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent mt-4 text-center"
                >
                    Chat Smarter. <br className=" md:hidden" /> Connect Better.
                </motion.h1>
                <motion.p
                    variants={{
                        hidden: { opacity: 0, y: 20 },
                        visible: { opacity: 1, y: 0 },
                    }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className=" hidden md:block max-w-xl text-center mt-2 text-white opacity-70"
                >
                    Chatly is your all-in-one messaging ap, seamlessly blending fast chats, smart AI replies, and private sharing in a beautifully simple interface.
                </motion.p>

                <motion.div
                    variants={{
                        hidden: { opacity: 0, y: 30 },
                        visible: { opacity: 1, y: 0 },
                    }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className=" flex flex-col w-full md:w-fit md:flex-row items-center gap-4 mt-6"
                >
                    <Button size="store" className=" w-[80%] max-w-sm md:w-fit">
                        <div className=" h-12 relative w-[132px] ">
                            <Image fill src="/assets/app-store.png" alt="App Store" quality={100} className=" object-contain" />
                        </div>
                    </Button>
                    <Button size="store" className=" w-[80%] max-w-sm md:w-fit">
                        <div className=" h-12 relative w-[132px] ">
                            <Image fill src="/assets/play-store.png" alt="Play Store" quality={100} className=" object-contain" />
                        </div>
                    </Button>
                </motion.div>
            </motion.div>


            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 1.5 }}
                className=" w-full relative -mt-12"
            >
                <div className="absolute hidden lg:block z-20 pointer-events-none w-[72vw] mx-auto h-full max-h-none top-0 inset-0 bg-[radial-gradient(60%_80%_at_50%_84%,rgba(18,18,18,0)_38.921734234234236%,#121212_100%)]" />
                <div className=" absolute lg:hidden top-0 inset-x-0 h-40 bg-gradient-to-t from-transparent to-background z-20" />
                <div className=" absolute bottom-0 inset-x-0 h-40 bg-gradient-to-b from-transparent to-background z-20" />
                <div className=" h-[180vh] overflow-clip flex items-center w-full justify-center">
                    <Marquee className="[--duration:40s] [--gap:32px] w-fit shrink-0" pauseOnHover vertical>
                        {appScreensColumn1.map((screen, index) => (
                            <div key={index} className=" w-[200px] h-[400px] md:w-[280px] md:h-[540px] relative overflow-clip opacity-50 hover:opacity-100 ease-in-out transition-opacity duration-300">
                                <Image fill src={`/assets/${screen}`} alt={`App screen ${index + 1}`} quality={40} className=" object-contain " />
                            </div>
                        ))}
                    </Marquee>
                    <Marquee className="[--duration:32s] [--gap:32px] w-fit shrink-0" pauseOnHover reverse vertical>
                        {appScreensColumn2.map((screen, index) => (
                            <div key={index} className=" w-[200px] h-[400px] md:w-[280px] md:h-[540px] relative overflow-clip opacity-50 hover:opacity-100 ease-in-out transition-opacity duration-300">
                                <Image fill src={`/assets/${screen}`} alt={`App screen ${index + 1}`} quality={40} className=" object-contain " />
                            </div>
                        ))}
                    </Marquee>
                    <Marquee className="[--duration:60s] [--gap:32px] w-fit shrink-0" pauseOnHover vertical>
                        {appScreensColumn3.map((screen, index) => (
                            <div key={index} className=" w-[200px] h-[400px] md:w-[280px] md:h-[540px] relative overflow-clip opacity-50 hover:opacity-100 ease-in-out transition-opacity duration-300">
                                <Image fill src={`/assets/${screen}`} alt={`App screen ${index + 1}`} quality={40} className=" object-contain " />
                            </div>
                        ))}
                    </Marquee>
                </div>
            </motion.div>
        </section >
    );
}

export default Hero;