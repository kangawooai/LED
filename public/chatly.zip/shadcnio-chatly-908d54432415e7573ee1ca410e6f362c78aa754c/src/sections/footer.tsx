import { Separator } from "@/components/ui/separator";
import { footerItems } from "@/constants";
import Image from "next/image";
import Link from "next/link";

import { FaSlack } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FaYoutube } from "react-icons/fa";
import { FaTiktok } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
import { FaDiscord } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";

const Footer = () => {
    return (
        <footer className=" w-full py-8">
            <div className=" max-w-7xl mx-auto lg:px-20 2xl:px-0">
                <div className=" w-full flex flex-col md:flex-row items-start md:items-center md:justify-between">
                    <Link className=" hidden md:block" href="/">
                        <div className=" relative h-9 w-[92px]">
                            <Image fill src="/assets/logo.png" quality={100} className=" object-contain" alt="Chatly Logo" />
                        </div>
                    </Link>

                    <div className="md:hidden">
                        <div className="size-32 relative">
                            <Image fill src="/assets/logo-icon.png" alt="Chatly Icon" className=" object-contain" />
                        </div>
                        <h4 className=" px-6 text-xl font-medium">
                            Experience the future of conversations with Chatly.
                        </h4>
                    </div>

                    <aside className=" flex flex-col md:flex-row md:justify-end gap-4 md:gap-6 w-full px-6 md:px-0 mt-8 md:mt-0">
                        {footerItems.map((item, index) => (
                            <Link className=" text-white/70 hover:text-white" key={index} href={item.href}>
                                <span>
                                    {item.title}
                                </span>
                            </Link>
                        ))}
                    </aside>
                </div>
                <Separator className=" opacity-20 mb-2 mt-6 hidden md:block" />
                <div className=" mt-12 md:mt-0 w-full flex flex-col-reverse md:flex-row items-center gap-12 md:gap-0 md:justify-between py-4">
                    <div>
                        <span className=" text-sm md:text-[15px]">
                            © 2025 Chatly Inc. All rights reserved.
                        </span>
                    </div>
                    <div className="flex flex-col md:flex-row items-start md:items-center gap-4 md:gap-6">
                        <span className=" text-[15px] hidden md:block">
                            Follow Our Socials
                        </span>
                        <div className=" flex items-center">
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-l border-r border-l-white/10 border-r-white/10">
                                <FaSlack size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaXTwitter size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaYoutube size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaTiktok size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaLinkedin size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaDiscord size={20} />
                            </div>
                            <div className=" text-white/70 hover:text-white w-12 h-9 flex items-center justify-center border-r border-r-white/10">
                                <FaInstagram size={20} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export default Footer;