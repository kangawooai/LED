import TestimonialCard from "@/components/common/testimonial-card";
import { Marquee } from "@/components/ui/marquee";
import { testimonials } from "@/constants";

const Testimonials = () => {
    return (
        <section id="testimonials" className="w-full py-20">
            <div className=" max-w-7xl px-4 md:px-0 lg:px-20 2xl:px-0 mx-auto flex flex-col items-start z-50 relative">
                <h3 className=" font-gt-walsheim font-medium text-4xl md:text-5xl tracking-tight bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent mt-4">Hear it from our users</h3>
            </div>

            <div className=" py-10 relative w-full">
                <div className=" absolute inset-y-0 left-0 bg-gradient-to-r from-background to-transparent w-1/4 z-20" />
                <div className=" absolute inset-y-0 right-0 bg-gradient-to-l from-background to-transparent w-1/4 z-20" />
                <Marquee>
                    {testimonials.map((testimonial, index) => (
                        <TestimonialCard key={index} testimonial={testimonial} />
                    ))}
                </Marquee>
            </div>
        </section>
    );
}

export default Testimonials;