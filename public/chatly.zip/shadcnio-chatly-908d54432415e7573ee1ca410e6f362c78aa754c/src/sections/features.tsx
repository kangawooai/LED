"use client"

import { Marquee } from "@/components/ui/marquee";
import { appScreensColumn1 } from "@/constants";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import { useRef } from "react";

const Features = () => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: true, amount: 0.2 });

    return (
        <section id="features" ref={ref} className=" w-full py-20">
            <div className=" px-4 md:px-0 lg:px-20 2xl:px-0 max-w-7xl mx-auto">
                <motion.h2
                    initial={{ opacity: 0, y: 30 }}
                    animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className="font-gt-walsheim font-medium text-4xl md:text-5xl tracking-tight bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent w-full text-center "
                >
                    Everything you need for smarter conversations.
                </motion.h2>
                <motion.div
                    initial="hidden"
                    animate={isInView ? "visible" : "hidden"}
                    variants={{
                        hidden: { opacity: 0 },
                        visible: {
                            opacity: 1,
                            transition: {
                                staggerChildren: 0.2,
                                delayChildren: 0.3,
                            },
                        },
                    }}
                    className="grid grid-cols-1 md:grid-cols-[1.5fr_1fr] gap-4 md:gap-3 w-full mt-8 md:mt-12"
                >
                    <motion.div
                        variants={{
                            hidden: { opacity: 0, x: -50 },
                            visible: { opacity: 1, x: 0 },
                        }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className=" w-full bg-muted border border-white/20 rounded-3xl  py-2 md:py-4 overflow-hidden h-[36rem]"
                    >
                        <div className=" px-4 md:px-8  py-2 md:py-4">
                            <h6 className=" font-gt-walsheim font-medium text-2xl tracking-tight">Instant Smart Replies</h6>
                            <p className=" text-sm md:text-[15px] text-white/70 mt-1">Never be stuck on what to say—Chatly’s AI suggests quick, natural responses that feel like you.</p>
                        </div>
                        <div className=" w-full overflow-hidden mt-4">
                            <Marquee className="[--duration:40s] [--gap:12px] w-full" pauseOnHover>
                                {appScreensColumn1.map((screen, index) => (
                                    <div key={index} className="w-[280px] h-[540px] relative overflow-clip opacity-50 hover:opacity-100 ease-in-out transition-opacity duration-300 flex-shrink-0">
                                        <Image fill src={`/assets/${screen}`} alt={`App screen ${index + 1}`} quality={40} className=" object-contain " />
                                    </div>
                                ))}
                            </Marquee>
                        </div>
                    </motion.div>
                    <motion.div
                        variants={{
                            hidden: { opacity: 0, x: 50 },
                            visible: { opacity: 1, x: 0 },
                        }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className=" w-full bg-muted border border-white/20 rounded-3xl px-4 md:px-8 py-2 md:py-4 flex flex-col items-start justify-between gap-12 md:gap-0"
                    >
                        <div className=" py-2 md:py-4">
                            <h6 className=" font-gt-walsheim font-medium text-2xl tracking-tight">Secure & Encrypted</h6>
                            <p className=" text-sm md:text-[15px] text-white/70 mt-1">Your messages stay yours. With end-to-end encryption, Chatly puts privacy at the heart of every chat.</p>
                        </div>

                        <div className=" py-2 md:py-4">
                            <span className="font-gt-walsheim font-medium text-2xl md:text-3xl tracking-tight bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent w-full text-center ">
                                chatly it!
                            </span>
                        </div>
                    </motion.div>
                </motion.div>

                <motion.div
                    initial="hidden"
                    animate={isInView ? "visible" : "hidden"}
                    variants={{
                        hidden: { opacity: 0 },
                        visible: {
                            opacity: 1,
                            transition: {
                                staggerChildren: 0.2,
                                delayChildren: 0.6,
                            },
                        },
                    }}
                    className="grid grid-cols-1 md:grid-cols-[1fr_1.5fr] gap-4 md:gap-3 w-full mt-4 md:mt-3"
                >
                    <motion.div
                        variants={{
                            hidden: { opacity: 0, y: 50 },
                            visible: { opacity: 1, y: 0 },
                        }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className=" w-full bg-muted border border-white/20 rounded-3xl  py-2 md:py-4 overflow-hidden"
                    >
                        <div className=" px-4 md:px-8  py-2 md:py-4">
                            <h6 className=" font-gt-walsheim font-medium text-2xl tracking-tight">Stay Connected Anywhere</h6>
                            <p className=" text-sm md:text-[15px] text-white/70 mt-1">Start a conversation on your phone and continue on your tablet or desktop without missing a beat.</p>
                        </div>
                    </motion.div>
                    <motion.div
                        variants={{
                            hidden: { opacity: 0, y: 50 },
                            visible: { opacity: 1, y: 0 },
                        }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className=" w-full bg-muted border border-white/20 rounded-3xl px-4 md:px-8  py-2 md:py-4 flex flex-col md:flex-row items-start justify-between h-[26rem] overflow-clip"
                    >
                        <div className=" py-2 md:py-4">
                            <h6 className=" font-gt-walsheim font-medium text-2xl tracking-tight">Rich Media Sharing</h6>
                            <p className=" text-sm md:text-[15px] text-white/70 mt-1">Share More Than Words</p>
                            <p className=" text-sm md:text-[15px] text-white/70 mt-1">Send photos, voice notes, documents, and even polls—all in a clean, intuitive chat experience.</p>
                        </div>

                        <div className="">
                            <div className="w-[320px] h-[600px] relative">
                                <Image fill src={`/assets/screen4.png`} alt={`Get started with Chatly`} quality={40} className=" object-contain " />
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            </div>
        </section>
    );
}

export default Features;