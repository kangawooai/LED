
"use client"

import React, { Dispatch, SetStateAction, useRef, useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";


export const SlideTabs = () => {
    const [position, setPosition] = useState<Position>({
        left: 0,
        width: 0,
        opacity: 0,
    });

    return (
        <ul
            onMouseLeave={() => {
                setPosition((pv) => ({
                    ...pv,
                    opacity: 0,
                }));
            }}
            className="relative hidden lg:flex w-fit items-center gap-2"
        >
            <Link href="/#features">
                <Tab setPosition={setPosition}>Features</Tab>
            </Link>
            <Link href="/#testimonials">
                <Tab setPosition={setPosition}>Testimonials</Tab>
            </Link>
            <Link href="/#faq">
                <Tab setPosition={setPosition}>FAQ</Tab>
            </Link>
            <Link href="mailto:contact@shadcn.io">
                <Tab setPosition={setPosition}>Contact Us</Tab>
            </Link>
            <Link href="/#download">
                <Tab setPosition={setPosition}>Download</Tab>
            </Link>

            <Cursor position={position} />
        </ul>
    );
};

const Tab = ({
    children,
    setPosition,
}: {
    children: string;
    setPosition: Dispatch<SetStateAction<Position>>;
}) => {
    const ref = useRef<null | HTMLLIElement>(null);

    return (
        <li
            ref={ref}
            onMouseEnter={() => {
                if (!ref?.current) return;

                const { width } = ref.current.getBoundingClientRect();

                setPosition({
                    left: ref.current.offsetLeft,
                    width,
                    opacity: 1,
                });
            }}
            className="relative text-nowrap z-10 block cursor-pointer px-4 text-sm text-white  md:text-base"
        >
            {children}
        </li>
    );
};

const Cursor = ({ position }: { position: Position }) => {
    return (
        <motion.li
            animate={{
                ...position,
            }}
            className="absolute z-0 h-8 rounded-full bg-primary md:h-10 top-1/2 -translate-y-1/2"
        />
    );
};

type Position = {
    left: number;
    width: number;
    opacity: number;
};