const TestimonialCard = ({ testimonial }: { testimonial: string }) => {
    const renderTestimonial = () => {
        const sentences = testimonial.split('. ');
        if (sentences.length < 2) {
            return testimonial;
        }

        const firstSentence = sentences[0] + '.';
        const remainingSentences = sentences.slice(1).join('. ');

        return (
            <>
                {firstSentence}{' '}
                <span className="bg-gradient-to-b from-secondary to-primary bg-clip-text text-transparent">
                    {remainingSentences}
                </span>
            </>
        );
    };

    return (
        <div className="bg-muted border w-[320px] md:w-[480px] border-white/20 rounded-3xl px-6 md:px-8 py-8 md:py-12 flex items-center justify-center">
            <p className=" text-xl text-balance">{renderTestimonial()}</p>
        </div>
    );
}

export default TestimonialCard;