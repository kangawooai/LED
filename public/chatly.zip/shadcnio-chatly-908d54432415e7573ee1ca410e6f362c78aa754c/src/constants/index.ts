export const appScreensColumn1 = [
  "screen1.png",
  "screen2.png",
  "screen3.png",
  "screen4.png",
];
export const appScreensColumn2 = [
  "screen5.png",
  "screen4.png",
  "screen3.png",
  "screen2.png",
];
export const appScreensColumn3 = [
  "screen1.png",
  "screen3.png",
  "screen4.png",
  "screen5.png",
];

export const testimonials = [
  "Finally, a chat app that actually cares about privacy. I can message freely knowing everything is encrypted end-to-end.",
  "Chatly makes staying in touch effortless. The AI replies save me so much time, and the design feels super modern compared to other apps.",
  "Finally, a chat app that actually cares about privacy. I can message freely knowing everything is encrypted end-to-end.",
  "Chatly makes staying in touch effortless. The AI replies save me so much time, and the design feels super modern compared to other apps.",
  "Finally, a chat app that actually cares about privacy. I can message freely knowing everything is encrypted end-to-end.",
  "Chatly makes staying in touch effortless. The AI replies save me so much time, and the design feels super modern compared to other apps.",
];

export const faqData = [
  {
    id: "item-1",
    question: "Is Chatly free to use?",
    answer:
      "Yes! Chatly is free to download and use. We also offer optional premium features for users who want extra customization and advanced tools.",
  },
  {
    id: "item-2",
    question: "How secure is Chatly?",
    answer:
      "Chatly uses end-to-end encryption to ensure your messages are completely private. Only you and the person you're messaging can read your conversations - not even we can access them.",
  },
  {
    id: "item-3",
    question: "Can I use Chatly on multiple devices?",
    answer:
      "Absolutely! Chatly syncs seamlessly across all your devices - phone, tablet, and desktop. Your conversations stay up-to-date everywhere you go.",
  },
  {
    id: "item-4",
    question: "What makes Chatly different from other messaging apps?",
    answer:
      "Chatly combines smart AI-powered replies, beautiful modern design, and top-tier privacy features all in one app. Plus, our interface is incredibly intuitive and fast.",
  },
  {
    id: "item-5",
    question: "Can I customize my chats?",
    answer:
      "Yes! Chatly offers extensive customization options including chat themes, notification settings, and AI reply preferences to make the app truly yours.",
  },
  {
    id: "item-6",
    question: "Does Chatly work offline?",
    answer:
      "Yes, you can read your message history offline. New messages will sync automatically when you're back online, so you never miss anything important.",
  },
];

export const footerItems = [
  {
    title: "Home",
    href: "/",
  },
  {
    title: "Features",
    href: "/#features",
  },
  {
    title: "FAQ",
    href: "/#faq",
  },
  {
    title: "Privacy Policy",
    href: "/privacy-policy",
  },
  {
    title: "Terms & Conditions",
    href: "/terms",
  },
];
